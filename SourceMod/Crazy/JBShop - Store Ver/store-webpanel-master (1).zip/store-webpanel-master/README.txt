====================
Store Webpanel
====================

1.Installation:
You can find the installation tutorial at https://github.com/Arrow768/store-webpanel/wiki/Installation-of-the-WebPanel

2.Support
You can get support:
In the Allied Mods Forum: https://forums.alliedmods.net/forumdisplay.php?f=157

3.Installation Service
If you are unable to install the Store Webpanel yourself, you can send me a PM in the Allied Mods Forum (Arrow768)

4. Supported version of the store plugin
If you want to use the latest version of the webpanel, you have to use the latest version of the store plugin.
If you want to use a outdated version of the store plugin, you have to use the version of the webpanel that has been released with the outdated store version
