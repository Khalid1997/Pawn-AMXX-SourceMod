<h1>Bot Manage Page</h1>
  <div class="alert alert-info"><strong>This is the bot management Dashboard</strong><br />
    One day, this page will be awesome, but now its just a placeholder</div>