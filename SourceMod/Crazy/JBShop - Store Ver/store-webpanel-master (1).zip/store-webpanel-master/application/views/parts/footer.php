<hr>
<footer>
    <p>&copy; 2013-2015 Store Plugin Developed by <a href="https://github.com/alongubkin/" target="_blank"><strong>alongub</strong></a> and <a href="https://github.com/Drixevel/" target="_blank"><strong>Drixevel</strong></a>. Code by <a href="https://github.com/Arrow768/" target="_blank"><strong>Arrow768</strong></a>. Design by <strong>Bor3d Gaming</strong>.
    <p><?php if(isset($version)):?><?php echo "WebPanel Version ".$version; ?><?php endif; ?> Go to <a href="https://github.com/SourceMod-Store/store-webpanel/issues/" target="_blank"><strong>Github</strong></a> to report Bugs and request Features.</p>
</footer>
</div>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>-->
<script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script> 
<script src="<?php echo base_url("assets/js/main.js") ?>"></script>
</body>
</html>