$(function () {
	$('#userTabs a:first').tab('show');
})