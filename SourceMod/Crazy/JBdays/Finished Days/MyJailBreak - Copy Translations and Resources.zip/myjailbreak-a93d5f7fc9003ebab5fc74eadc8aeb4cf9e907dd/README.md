## MyJailbreak
  
  a plugin pack for CS:GO jailserver
  
Download: https://shanapu.de/MyJailbreak  
Discuss: https://forums.alliedmods.net/showthread.php?t=283212  
Report: https://github.com/shanapu/MyJailbreak/issues  
Read: https://github.com/shanapu/MyJailbreak/wiki  
READ: https://github.com/shanapu/MyJailbreak/wiki/Frequently-Asked-Questions  
  
master: [![Build Status](https://img.shields.io/travis/shanapu/MyJailbreak/master.svg?style=flat-square)](https://travis-ci.org/shanapu/MyJailbreak?branch=master)  dev: [![Build Status](https://img.shields.io/travis/shanapu/MyJailbreak/dev.svg?style=flat-square)](https://travis-ci.org/shanapu/MyJailbreak?branch=dev)  
  
  
  
coded with ![](http://shanapu.de/githearth-small.png) free software
  
*my golden faucets not finance itself...* [ ![](http://shanapu.de/donate.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=QT8TVRSYWP53J)




